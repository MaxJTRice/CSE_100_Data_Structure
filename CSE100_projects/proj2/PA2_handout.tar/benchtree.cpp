#include "RST.hpp"
#include "countint.hpp"

using namespace std;



int main(int argc, char** argv) {
    cout << "# Benchmarking average number of comparisons for successful find" << endl;

    return 0;
}
